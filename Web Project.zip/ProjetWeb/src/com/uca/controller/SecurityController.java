package com.uca.controller;

import com.uca.core.UserCore;
import com.uca.dao._Connector;
import com.uca.entity.UserEntity;
import com.uca.gui._FreeMarkerInitializer;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import spark.Request;
import spark.Response;
import spark.Spark;
import static spark.Spark.*;


public class SecurityController {
    private final static String TOKEN = "KeMFH7Jlo3boQw0UWXvtM7D7OsiaoVBi5M2cgYh5xblOTneoPU";

    public static String create_token(String name,int status, boolean is_banned){
        Map<String,String> content = new HashMap<>();
        content.put("name", name);
        content.put("status", String.valueOf(status));
        content.put("is_banned", String.valueOf(is_banned));

        return Jwts.builder().setClaims(content)
                .setId(UUID.randomUUID().toString())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 *60))
                .signWith(SignatureAlgorithm.HS256, TOKEN)
                .compact();
    }

    public static Map<String,String> read_token(String token){
        Claims claims = Jwts.parser().setSigningKey(TOKEN).parseClaimsJws(token).getBody();
        Map<String ,String> map = new HashMap<>();
        map.put("name", claims.get("name", String.class));
        map.put("status", claims.get("status", String.class));
        map.put("is_banned", claims.get("is_banned", String.class));

        return map;
    }

    public static String connexion(Request req) throws IOException, TemplateException {
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = MainController.getToken_Map(req);

        Map<String, Object> input = new HashMap<>();
        MainController.valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("identification/connexion.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input ,output);

        return output.toString();
    }

    public static String do_connect(String username, String password, Request req) throws IOException, TemplateException {
        Connection connection = _Connector.getInstance();
        String dbPWD = "";
        String personal_TOKEN = null;

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE username = ?;");
            statement.setString(1,username);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()){
                UserEntity entity = new UserEntity();
                setEntity(entity, resultSet);
                dbPWD = entity.getPassword();
                personal_TOKEN = create_token(username, entity.getStatus(), entity.getIs_banned());
            }
        } catch (Exception e){
            System.out.println(e.toString());
            throw new RuntimeException("could not connect a user to database !");
        }
        if(UserCore.checkPassword(password, dbPWD)){

            return personal_TOKEN;
        }
        return null;
    }

    public static String register(Request req) throws IOException, TemplateException {
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, String> token_map = MainController.getToken_Map(req);

        Map<String, Object> input = new HashMap<>();
        MainController.valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("identification/register.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input, output);

        return output.toString();
    }

    public static String do_register(String username, String password, String email,Request req) throws IOException, TemplateException {
        String hashPwd = UserCore.hashPassword(password);

        Connection connection = _Connector.getInstance();
        try {
            PreparedStatement unique = connection.prepareStatement("SELECT username FROM users WHERE username = ? or email = ?;");
            unique.setString(1, username);
            unique.setString(2, email);
            ResultSet resultSet = unique.executeQuery();
            if(resultSet.next()){
                System.out.println("Nom ou adresse mail deja utilise");
                return register(req);
            }
            else {System.out.println("Ce nom existe pas");}
        }
        catch (Exception e){
            System.out.println(e.toString());
            throw new RuntimeException("could not create a new user to database !");
        }
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO users(username, password, email, status, is_banned) VALUES(?,?,?,?,?);");
            statement.setString(1, username);
            statement.setString(2, hashPwd);
            statement.setString(3, email);
            statement.setInt(4, 1);
            statement.setBoolean(5,false);
            statement.execute();
        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not create a new user to database !");
        }
        return connexion(req);
    }

    private static void setEntity(UserEntity entity, ResultSet resultSet) throws SQLException {
        entity.setId(resultSet.getInt("id"));
        entity.setUsername(resultSet.getString("username"));
        entity.setPassword(resultSet.getString("password"));
        entity.setStatus(resultSet.getInt("status"));
        entity.setIs_banned(resultSet.getBoolean("is_banned"));
    }

    public static String validManag (int id, String paramStatus, String paramIs_banned, Request req) throws IOException, TemplateException {
        int status = 2;
        boolean is_banned = true;
        Connection connection = _Connector.getInstance();
        if(paramStatus == null){
            status = 1;
        }
        if(paramIs_banned == null){
            is_banned = false;
        }
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE users SET status = ?, is_banned = ? WHERE id = ?;");
            statement.setInt(1, status);
            statement.setBoolean(2, is_banned);
            statement.setInt(3, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return getAllUsersForSuperadmin(req);
    }

    public static String getAllUsersForSuperadmin(Request req) throws IOException, TemplateException {
        Configuration configuration = _FreeMarkerInitializer.getContext();

        Map<String, Object> input = new HashMap<>();

        input.put("users", UserCore.getAllUsers());
        Map<String, String> token_map = MainController.getToken_Map(req);
        MainController.valueToken(input, token_map);

        Writer output = new StringWriter();
        Template template = configuration.getTemplate("users/usersManagement.ftl");
        template.setOutputEncoding("UTF-8");
        template.process(input, output);

        return output.toString();
    }
}
