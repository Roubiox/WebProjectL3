package com.uca;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.uca.controller.MainController;
import com.uca.controller.SecurityController;
import com.uca.core.ArticleCore;
import com.uca.core.CommentaryCore;
import com.uca.core.UserCore;
import com.uca.dao.CommentaryDAO;
import com.uca.dao._Initializer;
import com.uca.entity.ArticleEntity;

import com.uca.entity.CommentaryEntity;
import com.uca.entity.UserEntity;
import spark.Request;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static spark.Spark.*;

public class StartServer {

    public static void main(String[] args) {
        //Configure Spark
        staticFiles.location("/static");
        port(8081);

        _Initializer.Init();

        get("/", (req, res) -> MainController.accueil(req));
        get("/secret", (req, res) -> MainController.secret(req));
        //Defining our routes
        get("/articles", (req, res) -> MainController.getAllArticles(req));

        get("/createArticle", (req, res) -> MainController.createArticle(req));

        get("/connexion", (req, res) -> SecurityController.connexion(req));

        get("/register", (req, res) -> SecurityController.register(req));

        get("/usersManagement", (req, res) -> SecurityController.getAllUsersForSuperadmin(req));

        get("/readArticle", (req, res) -> MainController.readArticle(Integer.parseInt(req.queryParams("id")), req));

        get("/deleteArticle", (req,res) -> {
            String ID = req.queryParams("id");
            MainController.deleteArticle(ID);
            return MainController.getAllArticles(req);
        });

        post("/do_register", (req, res) ->{
            String username = req.queryParams("username");
            String password = req.queryParams("password");
            String email = req.queryParams("email");
            return SecurityController.do_register(username, password, email, req);
        });

        post("/validationManagement", (req,res) ->{
            int id = Integer.parseInt(req.queryParams("id"));
            String status = req.queryParams("status");
            String is_banned = req.queryParams("is_banned");
            return SecurityController.validManag(id, status, is_banned, req);
        });

        post("/do_connect", (req, res) ->{
            String username = req.queryParams("username");
            String password = req.queryParams("password");
            String personal_TOKEN = SecurityController.do_connect(username, password, req);
            res.cookie("auth",personal_TOKEN,36000);
            res.redirect("/", 301);
            return "";
        });

        get("/deconnexion", (req, res) ->{
            res.removeCookie("auth");
            res.redirect("/", 301);
            return "";
        });

        post("/formPost", (req, res) -> {
            String authName = SecurityController.read_token(req.cookie("auth")).get("name");
            String nameArticle = req.queryParams("nameArticle");
            String articleContent = req.queryParams("articleContent");
            MainController.postArticle(nameArticle,authName, articleContent);
            return MainController.getAllArticles(req);
        });

        post("/commentPost", (req, res) -> {
            String id_article = req.queryParams("id_article");
            String id_parent = req.queryParams("id_parent");
            String auth = SecurityController.read_token(req.cookie("auth")).get("name");
            String content = req.queryParams("newCommentary");
            CommentaryDAO.postCommentary(id_article,id_parent,auth,content);
            return MainController.readArticle(Integer.parseInt(id_article), req);
        });

        post("/commentDelete", (req, res) -> {
            int id = Integer.parseInt(req.queryParams("id"));
            int id_article = Integer.parseInt(req.queryParams("id_article"));
            MainController.deleteCommentary(id);
            return MainController.readArticle(id_article, req);
        });

        post("/editComment", (req, res) -> {
            int id_comment = Integer.parseInt(req.queryParams("id_comment"));
            int id_article = Integer.parseInt(req.queryParams("id_article"));
            String content = req.queryParams("content");
            MainController.editCommentary(id_comment,content);
            return MainController.readArticle(id_article, req);
        });
        post("/editArticle", (req, res) -> {
            int id_article = Integer.parseInt(req.queryParams("id_article"));
            String content = req.queryParams("articleContent");
            String title = req.queryParams("Titre");
            MainController.editArticle(id_article,content,title);
            return MainController.readArticle(id_article, req);
        });


        // API
        get("/api/articles", (req, res) -> {  // Récupère la liste intégrale des articles
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }

            ArrayList<ArticleEntity> entities = ArticleCore.getAllArticles();
            if (entities == null || entities.size() == 0) {
                res.status(204);
                return "";
            }

            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entities);
        });

        get("/api/articles/:author", (req,res) ->{  // Récupère la liste des articles écrits par un auteur
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }
            String authName = req.params(":author");
            ArrayList <ArticleEntity> entities = ArticleCore.getAllArticlesFromAuthor(authName);
            if (entities == null) {
                res.status(204);
                return "";
            }
            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entities);
        });
        get("/api/articles/:id", (req,res) ->{  // Récupère un article en fonction de son ID
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }
            int id = Integer.parseInt(req.params(":id"));
            ArticleEntity entity = ArticleCore.getArticle(id);
            if (entity == null) {
                res.status(204);
                return "";
            }
            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entity);
        });
        delete("/api/articles/:id", (req,res) ->{   // Supprime un article en fonction de son ID

            Map<String, String> Token = SecurityController.read_token(req.headers("Authorization"));
            if(!Boolean.parseBoolean(Token.get("is_banned")) && Integer.parseInt(Token.get("status")) > 1){
                String id = req.params(":id");
                MainController.deleteArticle(id);
                res.status(200);
                return "";
            }
            res.status(401);
            return "";
        });
        post("/api/articles", (req,res) ->{     // Créer et poste un article
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }
            ArticleEntity article = parseBody(req, ArticleEntity.class);
            Map<String, String> Token = SecurityController.read_token(req.headers("Authorization"));
            if(!Boolean.parseBoolean(Token.get("is_banned")) && Integer.parseInt(Token.get("status")) > 1){
                String authName = Token.get("name");
                if(article.getName() == null || article.getContent() == null){
                    res.status(400);
                    return "";
                }
                MainController.postArticle(article.getName(),authName,article.getContent());
                res.status(200);
                return "";
            }
            res.status(401);
            return "";

        });

        get("/api/articlesCommentary/:id", (req,res) ->{ // Récupère tous les commentaires d'un article en fonction de son ID
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }
            int id = Integer.parseInt(req.params(":id"));
            ArrayList<CommentaryEntity> entities = CommentaryCore.getAllCommentaryParentFromArticle(id);
            if (entities == null || entities.size() == 0) {
                res.status(204);
                return "";
            }

            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entities);
        });

        get("/api/users", (req,res) -> {  // Récupère la liste des utilisateurs
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }

            ArrayList<UserEntity> entities = UserCore.getAllUsers();
            if (entities == null || entities.size() == 0) {
                res.status(204);
                return "";
            }

            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entities);
        });

        get("/api/users/:username", (req,res) ->{ // Récupère les information d'un utilisateur
            Boolean useXML = useXML(req);
            if (useXML == null) {
                res.status(406);
                return "";
            }
            String username = req.params(":username");
            UserEntity entity = UserCore.getUserInfo(username);
            entity.setPassword("You don't have access to this");
            System.out.println("For " + entity.getUsername() + ", status :" + entity.getStatus() + " and is_banned : " + entity.getIs_banned());
            if(entity == null){
                res.status(204);
                return "";
            }
            res.header("Content-Type", useXML ? "application/xml" : "application/json");
            return parseContent(useXML, entity);
        });

        post("/api/login", (req,res) ->{ // Permet de se connecter pour pouvoir récupérer le token d'authorisation
            UserEntity user = parseBody(req, UserEntity.class);
            if(user == null){
                res.status(409);
                return "";
            }
            String Tok = SecurityController.do_connect(user.getUsername(),user.getPassword(),req);
            if(Tok == null){
                res.status(204);
                return "";
            }
            res.header("Auth", Tok);
            res.status(200);
            return "";
        });
    }
    private static <T> T parseBody(Request req, Class<T> expectedClass) throws JsonProcessingException {
        if(req.headers("Content-Type") != null){
            if(req.headers("Content-Type").equals("application/json")){
                ObjectMapper mapper = new ObjectMapper();
                return mapper.readValue(req.body(), expectedClass);
            } else if(req.headers("Content-Type").equals("application/xml")){
                XmlMapper mapper = new XmlMapper();
                return mapper.readValue(req.body(), expectedClass);
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
    private static Boolean useXML(Request req) {
        if (req.headers("Accept") != null && !req.headers("Accept").isEmpty() && !req.headers("Accept").equals("*/*")) {
            int json = req.headers("Accept").indexOf("application/json");
            int xml = req.headers("Accept").indexOf("application/xml");
            if (json == -1 && xml == -1) {
                return null;
            }
            if (xml == -1) {
                return false;
            } else {
                return json == -1 || json >= xml;
            }
        }
        return true;
    }
    private static String parseContent(boolean useXML, Object obj) throws JsonProcessingException {
        if (obj.getClass().getName().equals("java.util.ArrayList")) {
            Map<String, Object> map = new HashMap<>();
            map.put("content", obj);
            obj = map;
        }

        if (useXML) {
            XmlMapper xmlMapper = new XmlMapper();
            return xmlMapper.writeValueAsString(obj);
        }

        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }
}