package com.uca.dao;

import com.uca.entity.CommentaryEntity;

import java.sql.*;
import java.util.ArrayList;

public class CommentaryDAO extends _Generic<CommentaryEntity>{

    public ArrayList<CommentaryEntity> getAllCommentaryParentFromArticle(int article_id){
        ArrayList<CommentaryEntity> entities = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM commentaries WHERE id_article = ? AND id_parent = ? ORDER BY created_at DESC;");
            preparedStatement.setInt(1, article_id);
            preparedStatement.setInt(2,-1);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                CommentaryEntity entity = new CommentaryEntity();
                setEntity(entity, resultSet);

                entities.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return entities;
    }

    public ArrayList<CommentaryEntity> getAllCommentarySonFromArticle(ArrayList<CommentaryEntity> parentCommentaries){
        ArrayList<CommentaryEntity> entities = new ArrayList<>();
        for (CommentaryEntity parentCommentary : parentCommentaries){
            try {
                PreparedStatement preparedStatement = this.connect.prepareStatement("SELECT * FROM commentaries WHERE id_article = ? AND id_parent = ? ORDER BY created_at DESC;");
                preparedStatement.setInt(1, parentCommentary.getId_article());
                preparedStatement.setInt(2, parentCommentary.getId());
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    CommentaryEntity entity = new CommentaryEntity();
                    setEntity(entity, resultSet);

                    entities.add(entity);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        return entities;
    }
    private void setEntity(CommentaryEntity entity, ResultSet resultSet) throws SQLException {
        entity.setId(resultSet.getInt("id"));
        entity.setId_article(resultSet.getInt("id_article"));
        entity.setId_parent(resultSet.getInt("id_parent"));
        entity.setAuthor(resultSet.getString("author"));
        entity.setContent(resultSet.getString("content"));
        entity.setCreated_time(resultSet.getTimestamp("created_at"));
    }

    public static void postCommentary(String id_article, String id_parent, String auth, String content) {
        Connection connection = _Connector.getInstance();

        try {

            PreparedStatement statement = connection.prepareStatement("INSERT INTO commentaries(id_article, id_parent, author,content, created_at) VALUES(?, ?, ?, ?, ?);");
            statement.setInt(1,Integer.valueOf(id_article) );
            statement.setInt(2, Integer.valueOf(id_parent) );
            statement.setString(3, auth);
            statement.setString(4, content);
            statement.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
            statement.executeUpdate();


        } catch (Exception e) {
            System.out.println(e.toString());
            throw new RuntimeException("could not create new element in database !");
        }
    }

    @Override
    public CommentaryEntity create(CommentaryEntity obj) {
        return null;
    }

    @Override
    public void delete(CommentaryEntity obj) {
    }

}
