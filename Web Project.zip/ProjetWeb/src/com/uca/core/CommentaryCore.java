package com.uca.core;


import com.uca.dao.CommentaryDAO;
import com.uca.entity.CommentaryEntity;

import java.util.ArrayList;

public class CommentaryCore {

    public static ArrayList<CommentaryEntity> getAllCommentaryParentFromArticle(int article_id) { return new CommentaryDAO().getAllCommentaryParentFromArticle(article_id); }
    public static ArrayList<CommentaryEntity> getAllCommentarySonFromArticle(ArrayList<CommentaryEntity> commentaryParent) { return new CommentaryDAO().getAllCommentarySonFromArticle(commentaryParent); }

}
