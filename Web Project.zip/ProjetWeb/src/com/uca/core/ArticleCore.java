package com.uca.core;

import com.uca.dao.ArticleDAO;
import com.uca.entity.ArticleEntity;

import java.sql.SQLException;
import java.util.ArrayList;

public class ArticleCore {

    public static ArrayList<ArticleEntity> getAllArticles() {
        return new ArticleDAO().getAllArticles();
    }
    public static ArticleEntity getArticle(int id) throws SQLException { return new ArticleDAO().getArticle(id); }
    public static ArrayList<ArticleEntity> getAllArticlesFromAuthor(String authName) {return new ArticleDAO().getAllArticlesFromAuthor(authName); }
}
