function reponse(id){
    var block = document.getElementsByClassName(id);
    if (block[0].classList.contains('invisible')) {
        block[0].classList.remove('invisible');
        block[0].classList.add('visible');
    } else {
        block[0].classList.remove('visible');
        block[0].classList.add('invisible');
    }
}

function push(id){
    var block = document.getElementsByClassName(id);
    block[0].classList.remove('visible');
    block[0].classList.add('invisible');
}

function edit(id , contentTxt , id_article){
    console.log(contentTxt);
    console.log(id);
    console.log(id_article);
    var block = document.getElementById(id);
    block.classList.add('invisible');

    var actionTxt = "/editComment?id_article="+id_article+"&id_comment="+id;
    var newBlock = document.createElement('form');
    var div = document.createElement('div');
    var textarea = document.createElement('textarea');
    var content = document.createTextNode(contentTxt);
    var button = document.createElement('button');
    var edit = document.createTextNode("Edit");

    newBlock.setAttribute("method","post");
    newBlock.setAttribute("action",actionTxt);
    textarea.setAttribute("name","content");
    textarea.setAttribute("id","content");
    textarea.setAttribute("rows","3");
    textarea.setAttribute("required","");
    textarea.setAttribute("autofocus","");
    button.setAttribute("type","submit");

    div.setAttribute("class",'form-group box');
    textarea.setAttribute("class",'form-control');
    button.setAttribute("class",'btn btn-primary btn-sm button');

    button.appendChild(edit)
    textarea.appendChild(content);
    div.appendChild(textarea);
    newBlock.appendChild(div);
    newBlock.appendChild(button);

    //var test = "<form method=\"post\" action=\"/editComment?id_article=${article.id}&id_comment=${parentCommentary.id}\"> <div class=\"form-group box\"> <textarea class=\"form-control\" name=\"content\" id=\"content\" rows=\"3\" required=\"\" autofocus=\"\">"+content+"</textarea> </div><button class=\"w-100 btn btn-lg btn-primary button\" type=\"submit\">PUBLIER</button></form>";
    //newBlock.innerHTML = test;
    var editBlock = document.getElementsByClassName('editBlock-'+id);
    editBlock[0].appendChild(newBlock);
    console.log(newBlock);

}

function block(content){
    var newBlock = document.createElement('form');
    var div = document.createElement('div');
    var textarea = document.createElement('textarea');
    var content = document.createTextNode(content);
    var button = document.createElement('button');

    newBlock.setAttribute("method","post");
    newBlock.setAttribute("action","/editComment?id_article=${article.id}&id_comment=${parentCommentary.id}");
    textarea.setAttribute("name","content");
    textarea.setAttribute("id","content");
    textarea.setAttribute("rows","3");
    textarea.setAttribute("required","");
    textarea.setAttribute("autofocus","");
    button.setAttribute("type","submit");

    //newBlock.classList.add();
    div.classList.add('form-group box');
    textarea.classList.add('form-control');
    button.classList.add('w-100 btn btn-lg btn-primary button');

    textarea.appendChild(content);
    div.appendChild(textarea);
    newBlock.appendChild(div);
    newBlock.appendChild(button);
    return newBlock;
}
/*
"<form method=\"post\" action=\"/editComment?id_article=${article.id}&id_comment=${parentCommentary.id}\">
    <div class=\"form-group box\">
        <textarea class=\"form-control\" name=\"content\" id=\"content\" rows=\"3\" required=\"\" autofocus=\"\">"+content+"</textarea>
    </div>
    <button class=\"w-100 btn btn-lg btn-primary button\" type=\"submit\">PUBLIER</button>
</form>"*/

