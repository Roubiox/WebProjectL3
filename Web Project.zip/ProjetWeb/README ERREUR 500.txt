En cas d'erreur 500 sur toute les pages alors ecrire: localhost:8081/deconnexion
dans la barre des taches

Il y a un beug avec les cookies.